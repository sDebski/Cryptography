WERSJA:
python >= 3.6

POLECENIE URUCHAMIANIA: 
python3 hash_diff.py --fpath hash.txt